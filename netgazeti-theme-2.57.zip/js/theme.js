/* Netgazeti theme — vanilla JS (replaces jQuery + Owl Carousel) */
(function () {
    'use strict';

    // ── Search overlay ─────────────────────────────────────────
    var openBtn  = document.getElementById('searchOpen');
    var closeBtn = document.getElementById('searchClose');
    var overlay  = document.getElementById('searchOverlay');

    if (openBtn && overlay) {
        openBtn.addEventListener('click', function () {
            overlay.style.display = 'block';
            var input = overlay.querySelector('input[name="s"]');
            if (input) { setTimeout(function () { input.focus(); }, 50); }
        });
    }
    if (closeBtn && overlay) {
        closeBtn.addEventListener('click', function () {
            overlay.style.display = 'none';
        });
    }
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && overlay && overlay.style.display === 'block') {
            overlay.style.display = 'none';
        }
    });

    // ── Back-to-top ────────────────────────────────────────────
    var backToTop = document.getElementById('backToTop');
    if (backToTop) {
        var toggleBtt = function () {
            if (window.pageYOffset > 120) {
                backToTop.style.opacity  = '1';
                backToTop.style.pointerEvents = 'auto';
            } else {
                backToTop.style.opacity  = '0';
                backToTop.style.pointerEvents = 'none';
            }
        };
        backToTop.style.transition = 'opacity 0.3s';
        backToTop.style.opacity = '0';
        backToTop.style.pointerEvents = 'none';
        toggleBtt();
        window.addEventListener('scroll', toggleBtt, { passive: true });

        backToTop.addEventListener('click', function (e) {
            e.preventDefault();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // ── Smooth scroll for in-page anchors ─────────────────────
    document.querySelectorAll('a[href*="#"]:not([href="#"])').forEach(function (link) {
        link.addEventListener('click', function (e) {
            var hash = link.getAttribute('href').split('#')[1];
            if (!hash) return;
            var target = document.getElementById(hash) ||
                         document.querySelector('[name="' + hash + '"]');
            if (target && link.pathname === window.location.pathname) {
                e.preventDefault();
                target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });

    // ── Swiper carousels ──────────────────────────────────────
    function initSwipers() {
        if (typeof Swiper === 'undefined') { return; }

        document.querySelectorAll('.tag-carousel').forEach(function (el) {
            new Swiper(el, {
                loop: true,
                autoplay: { delay: 5000, disableOnInteraction: true, pauseOnMouseEnter: true },
                spaceBetween: 15,
                slidesPerView: 1,
                breakpoints: {
                    600:  { slidesPerView: 2 },
                    1000: { slidesPerView: 3 }
                },
                navigation: false,
                pagination: { el: el.querySelector('.swiper-pagination'), clickable: true }
            });
        });

        document.querySelectorAll('.ukraine-carousel').forEach(function (el) {
            new Swiper(el, {
                loop: true,
                spaceBetween: 10,
                slidesPerView: 1,
                breakpoints: {
                    600:  { slidesPerView: 3 },
                    1000: { slidesPerView: 4 }
                },
                navigation: false,
                pagination: { el: el.querySelector('.swiper-pagination'), clickable: true }
            });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initSwipers);
    } else {
        initSwipers();
    }
})();
