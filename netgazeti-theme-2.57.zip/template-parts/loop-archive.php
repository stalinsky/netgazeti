<?php
/**
 * Loop partial for archive-like screens.
 * Used by: archive.php, category.php, tag.php, author.php, search.php
 *
 * Available context (set by the parent template before include):
 *   $loop_title  (string, optional) — heading shown above the grid
 *   $loop_intro  (string, optional) — sub-heading / search summary
 *   $loop_size   (string, optional) — 'h1' (default) or 'h3'
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

$loop_size  = isset( $loop_size ) ? $loop_size : 'h1';
$loop_title = isset( $loop_title ) ? $loop_title : '';
$loop_intro = isset( $loop_intro ) ? $loop_intro : '';
?>

<div class="container">

    <?php if ( $loop_title ) : ?>
        <<?php echo esc_html( $loop_size ); ?> class="title text-muted my-3"><?php echo esc_html( $loop_title ); ?></<?php echo esc_html( $loop_size ); ?>>
    <?php endif; ?>

    <?php if ( $loop_intro ) : ?>
        <p class="text-muted mb-4"><?php echo wp_kses_post( $loop_intro ); ?></p>
    <?php endif; ?>

    <?php if ( have_posts() ) : ?>
        <div class="row">
            <?php while ( have_posts() ) : the_post(); ?>
                <div class="col-lg-4 col-md-4 col-sm-6 mb-5">
                    <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                        <?php if ( has_post_thumbnail() ) : ?>
                            <img src="<?php the_post_thumbnail_url(); ?>"
                                 alt="<?php the_title_attribute(); ?>"
                                 title="<?php the_title_attribute(); ?>"
                                 class="img-fluid" width="800" height="450" loading="lazy">
                        <?php else : ?>
                            <img src="<?php echo get_template_directory_uri(); ?>/images/no-featured-image.png"
                                 alt="<?php the_title_attribute(); ?>"
                                 class="img-fluid" width="800" height="450" loading="lazy">
                        <?php endif; ?>
                    </a>
                    <small><?php echo esc_html( format_post_date() ); ?></small>
                    <h5>
                        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" class="text-dark">
                            <?php the_title(); ?>
                        </a>
                    </h5>
                </div>
            <?php endwhile; ?>
        </div>

        <hr>
        <?php the_posts_pagination( [ 'end_size' => 2 ] ); ?>

    <?php else : ?>
        <div class="py-5 text-center">
            <h2 class="text-muted">Ничего не найдено</h2>
            <p class="text-muted">Попробуйте изменить запрос или вернуться <a href="<?php echo esc_url( home_url( '/' ) ); ?>">на главную</a>.</p>
        </div>
    <?php endif; ?>

</div>
